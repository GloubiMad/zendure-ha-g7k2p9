"""Constants for Zendure."""

from datetime import timedelta
from enum import Enum

DOMAIN = "zendure_ha"

CONF_APPTOKEN = "token"
CONF_P1METER = "p1meter"
CONF_PRICE = "price"
CONF_MQTTLOG = "mqttlog"
CONF_MQTT_INFLUX = "mqtt_influx"  # journaliser les messages MQTT bruts vers un bucket InfluxDB dédié
CONF_MQTTLOCAL = "mqttlocal"
CONF_MQTTSERVER = "mqttserver"
CONF_SIM = "simulation"
CONF_MQTTPORT = "mqttport"
CONF_MQTTUSER = "mqttuser"
CONF_MQTTPSW = "mqttpsw"
CONF_WIFISSID = "wifissid"
CONF_WIFIPSW = "wifipsw"
CONF_AUTO_MQTT_USER = "auto_mqtt_user"
CONF_TELEGRAM_ENTITY_ID = "telegram_entity_id"  # legacy, kept for migration
CONF_NOTIFY_TARGETS = "notify_targets"  # list of notify.* entities for alerts

# InfluxDB v2 exporter (dedicated bucket telemetry trace)
CONF_INFLUX_ENABLE = "influx_enable"
CONF_INFLUX_URL = "influx_url"
CONF_INFLUX_ORG = "influx_org"
CONF_INFLUX_TOKEN = "influx_token"
CONF_INFLUX_BUCKET = "influx_bucket"

CONF_HAKEY = "C*dafwArEOXK"


class AcMode:
    INPUT = 1
    OUTPUT = 2


class DeviceState(Enum):
    OFFLINE = 0
    SOCEMPTY = 1
    INACTIVE = 2
    SOCFULL = 3
    ACTIVE = 4


class ManagerMode(Enum):
    OFF = 0
    MANUAL = 1
    MATCHING = 2
    MATCHING_DISCHARGE = 3
    MATCHING_CHARGE = 4
    STORE_SOLAR = 5
    MONITOR = 6


class ManagerState(Enum):
    IDLE = 0
    CHARGE = 1
    DISCHARGE = 2
    OFF = 3


class SmartMode:
    SOCFULL = 1
    SOCEMPTY = 2
    ZENSDK = 2
    CONNECTED = 10

    TIMEFAST = 2.2  # Fast update interval after significant change
    TIMEZERO = 4  # Normal update interval

    # Standard deviation thresholds for detecting significant changes
    P1_STDDEV_FACTOR = 3.5  # Multiplier for P1 meter stddev calculation
    # 15 -> 30 : seuil plancher de "changement significatif" du P1. À 15 W, le
    # bruit du compteur déclenchait des redistributions rapides en boucle
    # (sur-correction ±200 W période ~10 s autour du point d'équilibre,
    # micro-exports qui basculaient charge/décharge). À 30 W, les
    # micro-variations passent par le chemin lent (TIMEZERO) au lieu du fast.
    P1_STDDEV_MIN = 30  # Minimum stddev value for P1 changes (watts)
    P1_MIN_UPDATE = timedelta(milliseconds=400)
    SETPOINT_STDDEV_FACTOR = 5.0  # Multiplier for power average stddev calculation
    SETPOINT_STDDEV_MIN = 50  # Minimum stddev value for power average (watts)

    HEMSOFF_TIMEOUT = 60  # Seconds before HEMS state is set to OFF if no updates are received

    POWER_START = 50  # Minimum Power (W) for starting a device
    POWER_TOLERANCE = 5  # Device-level power tolerance (W) before updating

    # On every MQTT message a device's lastseen is stamped at now + this many
    # seconds; once wall-clock passes it the device is treated as offline.
    # The real time of the last message is therefore lastseen - this offset.
    MQTT_LASTSEEN_OFFSET = 300  # 5 min liveness window (shared device/manager)

    # MQTT staleness watchdog: a client can report is_connected()==True while
    # the broker has silently dropped a device's subscription, so no data
    # reaches HA. Zendure devices normally report every ~1s (day) and at worst
    # every ~60s (coordinator poll), so 150s of silence is already clearly
    # abnormal. We then re-subscribe the device's topics; if the WHOLE client
    # delivers nothing past MQTT_RECONNECT_TIMEOUT the socket is likely
    # half-open and we force a reconnect.
    MQTT_STALE_TIMEOUT = 150  # seconds of silence before re-subscribing a device
    MQTT_RECONNECT_TIMEOUT = 420  # total-blackout silence before forcing a reconnect
    MQTT_RESUB_COOLDOWN = 120  # minimum seconds between recovery actions per device

    # Watchdog de COMMANDE (orthogonal au watchdog MQTT) : un onduleur peut rester
    # vivant sur MQTT (lastseen frais) tout en IGNORANT les commandes — le firmware
    # se fige sur une valeur (incidents vécus : -250 W en charge, 137 W en décharge)
    # et seul un reboot matériel (débranchement) le débloque. On compare la consigne
    # envoyée (cmd_target) au réalisé (homeOutput - homeInput) : si l'écart dépasse
    # CMD_STUCK_GAP ET que le réalisé reste figé (variation ≤ CMD_STUCK_FREEZE) pendant
    # CMD_STUCK_CYCLES cycles consécutifs, on notifie une fois (puis cooldown).
    # NB : ne se déclenche QUE si on demande réellement une puissance (écart > seuil) ;
    # un device au repos à 0 W parce qu'on ne lui demande rien (ex. glagla plein,
    # export interdit) a un écart nul → jamais d'alerte.
    CMD_STUCK_GAP = 150  # W d'écart consigne/réalisé considéré comme "non suivi"
    CMD_STUCK_FREEZE = 20  # W de variation max du réalisé entre 2 cycles pour le dire "figé"
    CMD_STUCK_CYCLES = 6  # cycles consécutifs figés avant alerte (~30-40 s)
    CMD_STUCK_COOLDOWN = 1800  # s minimum entre 2 notifs pour un même device

    # Stratégie SoC plein (select manager) : que fait un device plein de son surplus solaire.
    STRAT_FULL_SOLAR = 0  # actuel : passe tout son solaire (peut exporter si non absorbé)
    STRAT_NO_EXPORT = 1  # zéro export réseau : surplus crédité -> encaissé par l'autre batterie
    #                      (phase 2 à venir : écrêter la sortie si l'autre batterie est pleine aussi)

    # === Moteur de régulation "smooth-ramp" (portage zoic21 + asymétrie §6bis) ================
    # Pipeline appliqué au setpoint DÉJÀ corrigé (après ré-ajout de la sortie des devices) :
    #   EMA asymétrique -> rate-limiter -> σ(60 s) -> hysteresis -> deadband -> direction-guard.
    # INACTIF tant que regulation_engine = legacy (défaut). Implémentation : signal.py (classe pure,
    # zéro dépendance HA, rejouable offline via tools/replay_signal.py). Cf. tools/portage-moteur-
    # smooth-ramp.md pour la justification de chaque couche et la baseline cloud cible.
    REGULATION_LEGACY = 0  # moteur actuel (stddev / isFast / plancher-maintien) — défaut
    REGULATION_SMOOTH = 1  # nouveau pipeline lissé

    SMOOTH_CYCLE = 2.0  # s, cadence nominale de recalcul (réf. zoic21)
    # EMA asymétrique (§6bis-1 « recule vite / avance doucement », tempéré par §6bis-5) :
    #  - avance (|setpoint| AUGMENTE, loin de 0) = lissage anti-yo-yo
    #  - recul (|setpoint| DIMINUE, vers 0)      = réponse rapide (on ne fait pas mieux que le ~4 s HW)
    SMOOTH_EMA_ALPHA = 0.3  # avance : Slow .1 / Medium .3 / Fast .5
    SMOOTH_EMA_ALPHA_RECEDE = 0.6  # recul : plus réactif, mais "sans excès"
    SMOOTH_RATE_THRESHOLD = 250  # W, saut d'EMA au-delà duquel on amortit (avance seulement)
    SMOOTH_RATE_FACTOR = 0.75  # fraction du delta appliquée au-dessus du seuil
    SMOOTH_SIGMA_SAMPLES = 30  # échantillons pour σ (≈ 60 s à 2 s) — informe deadband + hysteresis
    SMOOTH_HYST_PEAK = 2.0  # écart > PEAK×σ au mean60 = pic statistique -> suivre le mean (charges cycliques)
    SMOOTH_DEADBAND_SHIFT = 20  # W, biais anti-export (§6bis-4) : on vise +SHIFT d'import léger plutôt que 0
    SMOOTH_DEADBAND_MIN = 20  # W, demi-largeur plancher de la deadband (jour calme)
    SMOOTH_DEADBAND_SIGMA = 1.0  # multiplicateur σ pour la largeur adaptative (jour volatil -> plus large)
    SMOOTH_DRIFT = 15  # W/cycle, dérive douce de la sortie vers le centre quand on est dans la deadband
    SMOOTH_GUARD_THRESHOLD = 250  # W, chute brutale franchissant 0 au-delà de ce seuil = gel anti-flip
    SMOOTH_GUARD_MAX = 8.0  # s, durée max du gel direction-guard avant d'autoriser le flip de mode
