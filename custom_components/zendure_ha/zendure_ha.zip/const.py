"""Constants for Zendure."""

from datetime import timedelta
from enum import Enum

DOMAIN = "zendure_ha"

CONF_APPTOKEN = "token"
CONF_P1METER = "p1meter"
CONF_PRICE = "price"
CONF_MQTTLOG = "mqttlog"
CONF_MQTTLOCAL = "mqttlocal"
CONF_MQTTSERVER = "mqttserver"
CONF_SIM = "simulation"
CONF_MQTTPORT = "mqttport"
CONF_MQTTUSER = "mqttuser"
CONF_MQTTPSW = "mqttpsw"
CONF_WIFISSID = "wifissid"
CONF_WIFIPSW = "wifipsw"
CONF_AUTO_MQTT_USER = "auto_mqtt_user"
CONF_TELEGRAM_ENTITY_ID = "telegram_entity_id"  # legacy, kept for migration
CONF_NOTIFY_TARGETS = "notify_targets"  # list of notify.* entities for alerts

# InfluxDB v2 exporter (dedicated bucket telemetry trace)
CONF_INFLUX_ENABLE = "influx_enable"
CONF_INFLUX_URL = "influx_url"
CONF_INFLUX_ORG = "influx_org"
CONF_INFLUX_TOKEN = "influx_token"
CONF_INFLUX_BUCKET = "influx_bucket"

CONF_HAKEY = "C*dafwArEOXK"


class AcMode:
    INPUT = 1
    OUTPUT = 2


class DeviceState(Enum):
    OFFLINE = 0
    SOCEMPTY = 1
    INACTIVE = 2
    SOCFULL = 3
    ACTIVE = 4


class ManagerMode(Enum):
    OFF = 0
    MANUAL = 1
    MATCHING = 2
    MATCHING_DISCHARGE = 3
    MATCHING_CHARGE = 4
    STORE_SOLAR = 5
    MONITOR = 6


class ManagerState(Enum):
    IDLE = 0
    CHARGE = 1
    DISCHARGE = 2
    OFF = 3


class SmartMode:
    SOCFULL = 1
    SOCEMPTY = 2
    ZENSDK = 2
    CONNECTED = 10

    TIMEFAST = 2.2  # Fast update interval after significant change
    TIMEZERO = 4  # Normal update interval

    # Standard deviation thresholds for detecting significant changes
    P1_STDDEV_FACTOR = 3.5  # Multiplier for P1 meter stddev calculation
    # 15 -> 30 : seuil plancher de "changement significatif" du P1. À 15 W, le
    # bruit du compteur déclenchait des redistributions rapides en boucle
    # (sur-correction ±200 W période ~10 s autour du point d'équilibre,
    # micro-exports qui basculaient charge/décharge). À 30 W, les
    # micro-variations passent par le chemin lent (TIMEZERO) au lieu du fast.
    P1_STDDEV_MIN = 30  # Minimum stddev value for P1 changes (watts)
    P1_MIN_UPDATE = timedelta(milliseconds=400)
    SETPOINT_STDDEV_FACTOR = 5.0  # Multiplier for power average stddev calculation
    SETPOINT_STDDEV_MIN = 50  # Minimum stddev value for power average (watts)

    HEMSOFF_TIMEOUT = 60  # Seconds before HEMS state is set to OFF if no updates are received

    POWER_START = 50  # Minimum Power (W) for starting a device
    POWER_TOLERANCE = 5  # Device-level power tolerance (W) before updating

    # On every MQTT message a device's lastseen is stamped at now + this many
    # seconds; once wall-clock passes it the device is treated as offline.
    # The real time of the last message is therefore lastseen - this offset.
    MQTT_LASTSEEN_OFFSET = 300  # 5 min liveness window (shared device/manager)

    # MQTT staleness watchdog: a client can report is_connected()==True while
    # the broker has silently dropped a device's subscription, so no data
    # reaches HA. Zendure devices normally report every ~1s (day) and at worst
    # every ~60s (coordinator poll), so 150s of silence is already clearly
    # abnormal. We then re-subscribe the device's topics; if the WHOLE client
    # delivers nothing past MQTT_RECONNECT_TIMEOUT the socket is likely
    # half-open and we force a reconnect.
    MQTT_STALE_TIMEOUT = 150  # seconds of silence before re-subscribing a device
    MQTT_RECONNECT_TIMEOUT = 420  # total-blackout silence before forcing a reconnect
    MQTT_RESUB_COOLDOWN = 120  # minimum seconds between recovery actions per device

    # Watchdog de COMMANDE (orthogonal au watchdog MQTT) : un onduleur peut rester
    # vivant sur MQTT (lastseen frais) tout en IGNORANT les commandes — le firmware
    # se fige sur une valeur (incidents vécus : -250 W en charge, 137 W en décharge)
    # et seul un reboot matériel (débranchement) le débloque. On compare la consigne
    # envoyée (cmd_target) au réalisé (homeOutput - homeInput) : si l'écart dépasse
    # CMD_STUCK_GAP ET que le réalisé reste figé (variation ≤ CMD_STUCK_FREEZE) pendant
    # CMD_STUCK_CYCLES cycles consécutifs, on notifie une fois (puis cooldown).
    # NB : ne se déclenche QUE si on demande réellement une puissance (écart > seuil) ;
    # un device au repos à 0 W parce qu'on ne lui demande rien (ex. glagla plein,
    # export interdit) a un écart nul → jamais d'alerte.
    CMD_STUCK_GAP = 150  # W d'écart consigne/réalisé considéré comme "non suivi"
    CMD_STUCK_FREEZE = 20  # W de variation max du réalisé entre 2 cycles pour le dire "figé"
    CMD_STUCK_CYCLES = 6  # cycles consécutifs figés avant alerte (~30-40 s)
    CMD_STUCK_COOLDOWN = 1800  # s minimum entre 2 notifs pour un même device
