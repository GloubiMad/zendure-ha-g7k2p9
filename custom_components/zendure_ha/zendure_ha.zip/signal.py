"""Moteur de régulation « smooth-ramp » — traitement du signal (pur, sans HA).

Porté de la spec `zoic21/auto-discovery` (cf. tools/ref-moteur-zoic21/) avec nos
décisions de design §6bis (cf. tools/portage-moteur-smooth-ramp.md). Cette classe
est VOLONTAIREMENT pure : aucune dépendance Home Assistant, aucun I/O. Elle prend
en entrée le setpoint DÉJÀ corrigé (P1 ré-ajouté de la sortie des devices, ce que
fait powerChanged) et rend un setpoint lissé prêt pour la distribution.

But : être rejouable hors-ligne (tools/replay_signal.py) sur un simulation.csv
enregistré, pour valider la math contre la baseline cloud AVANT de toucher le
système réel. Chaque couche est activable séparément (flags `Config`) pour l'A/B
couche par couche (plan P1..P5).

Pipeline (sens du signe : setpoint > 0 = décharge attendue, < 0 = charge) :
    setpoint corrigé
      -> EMA asymétrique     (avance lent / recul rapide)
      -> rate-limiter        (amortit les gros sauts en AVANCE)
      -> σ sur 60 s          (alimente hysteresis + deadband)
      -> hysteresis          (filtre les pics statistiques : charges cycliques)
      -> deadband            (biais anti-export + largeur adaptative + dérive douce)
      -> direction-guard     (anti-flip charge<->décharge sur transitoire)
      -> setpoint lissé
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from math import sqrt

try:
    from .const import SmartMode
except ImportError:  # rejeu hors-ligne (tools/replay_signal.py) : import à plat, sans le package HA
    from const import SmartMode  # type: ignore[no-redef]


@dataclass
class SignalConfig:
    """Paramètres du pipeline (défauts = const.SmartMode, surchargeables pour l'A/B)."""

    ema_alpha: float = SmartMode.SMOOTH_EMA_ALPHA
    ema_alpha_recede: float = SmartMode.SMOOTH_EMA_ALPHA_RECEDE
    rate_threshold: float = SmartMode.SMOOTH_RATE_THRESHOLD
    rate_factor: float = SmartMode.SMOOTH_RATE_FACTOR
    sigma_samples: int = SmartMode.SMOOTH_SIGMA_SAMPLES
    hyst_peak: float = SmartMode.SMOOTH_HYST_PEAK
    deadband_shift: float = SmartMode.SMOOTH_DEADBAND_SHIFT
    deadband_min: float = SmartMode.SMOOTH_DEADBAND_MIN
    deadband_sigma: float = SmartMode.SMOOTH_DEADBAND_SIGMA
    drift: float = SmartMode.SMOOTH_DRIFT
    guard_threshold: float = SmartMode.SMOOTH_GUARD_THRESHOLD
    guard_max: float = SmartMode.SMOOTH_GUARD_MAX

    # Activation par couche (pour valider une couche à la fois — plan P1..P5).
    use_ema: bool = True
    use_rate_limiter: bool = True
    use_hysteresis: bool = True
    use_deadband: bool = True
    use_guard: bool = True


class SignalProcessor:
    """État + pipeline de lissage d'un flux de setpoints corrigés.

    Une instance par manager. `process(setpoint, elapsed)` est appelé à chaque
    cycle (cadence ~2 s) ; `elapsed` est le temps écoulé depuis le dernier appel
    (secondes), utilisé pour les couches temporelles (direction-guard). On
    raisonne en échantillons (et non en secondes) pour σ : la fenêtre est
    `sigma_samples` derniers points (≈ 60 s à 2 s/cycle).
    """

    def __init__(self, config: SignalConfig | None = None) -> None:
        self.cfg = config or SignalConfig()
        self.reset()

    def reset(self) -> None:
        """Repart d'un état neutre (au démarrage, ou au changement de moteur)."""
        self.ema: float | None = None  # None = pas encore amorcé
        self.prev_ema: float = 0.0  # EMA du cycle précédent (delta du rate-limiter)
        self.prev_out: float = 0.0  # dernière sortie émise (deadband + guard)
        self.history: deque[float] = deque(maxlen=self.cfg.sigma_samples)  # EMA récents pour σ
        self.guard_remaining: float = 0.0  # s de gel restantes (direction-guard)
        self.guard_side: int = 0  # signe figé pendant le gel (+1 décharge / -1 charge)

    # ------------------------------------------------------------------ pipeline
    def process(self, setpoint: float, elapsed: float = SmartMode.SMOOTH_CYCLE) -> int:
        """Fait passer un setpoint corrigé dans tout le pipeline ; rend l'entier lissé."""
        value = float(setpoint)

        # 1) EMA asymétrique
        if self.cfg.use_ema:
            value = self._ema(value)

        # 2) Rate-limiter (sur la valeur EMA, amortit les sauts en avance)
        if self.cfg.use_ema and self.cfg.use_rate_limiter:
            value = self._rate_limit(value)

        # σ tenu à jour à partir de la valeur lissée (avant deadband/guard).
        self.history.append(value)
        sigma = self._sigma()

        # 3) Hysteresis : filtre de pics statistiques (charges cycliques -> suit le mean).
        if self.cfg.use_hysteresis:
            value = self._hysteresis(value, sigma)

        # 4) Deadband : biais anti-export + largeur adaptative + dérive douce.
        if self.cfg.use_deadband:
            value = self._deadband(value, sigma)

        # 5) Direction-guard : anti-flip charge<->décharge sur transitoire.
        if self.cfg.use_guard:
            value = self._guard(value, elapsed)

        self.prev_out = value
        return int(round(value))

    # ------------------------------------------------------------------ couches
    def _ema(self, value: float) -> float:
        """EMA à α asymétrique : recul (vers 0) rapide, avance (loin de 0) lente."""
        if self.ema is None:
            self.ema = value
            self.prev_ema = value
            return value
        self.prev_ema = self.ema  # mémorise l'EMA précédent pour le rate-limiter
        # Recul = la magnitude demandée diminue (ou on franchit 0 vers l'autre côté).
        receding = abs(value) < abs(self.ema) or (value * self.ema) < 0
        alpha = self.cfg.ema_alpha_recede if receding else self.cfg.ema_alpha
        self.ema = alpha * value + (1.0 - alpha) * self.ema
        return self.ema

    def _rate_limit(self, value: float) -> float:
        """Amortit un saut d'EMA > seuil, mais UNIQUEMENT en avance (loin de 0).

        En recul (vers 0) on laisse passer : couper un débit doit rester rapide
        (§6bis-1). L'amortissement ne s'applique donc qu'aux montées de magnitude,
        et amortit vers l'EMA précédent (réf. zoic21 §6.2).
        """
        delta = value - self.prev_ema
        advancing = abs(value) > abs(self.prev_ema) and (value * self.prev_ema) >= 0
        if advancing and abs(delta) > self.cfg.rate_threshold:
            value = self.prev_ema + self.cfg.rate_factor * delta
            self.ema = value  # l'EMA suit la sortie amortie (évite de ré-accélérer au cycle suivant)
        return value

    def _sigma(self) -> float:
        """Écart-type des derniers échantillons lissés (volatilité récente)."""
        n = len(self.history)
        if n < 2:
            return 0.0
        mean = sum(self.history) / n
        return sqrt(sum((x - mean) ** 2 for x in self.history) / n)

    def _hysteresis(self, value: float, sigma: float) -> float:
        """Filtre de pics : un écart > PEAK×σ au mean60 est un outlier -> suit le mean.

        Gère les charges cycliques (micro-ondes 100<->900 W) : leur mean est stable
        avec σ élevé, chaque crête dépasse 2σ en alternance -> on suit ~le mean au lieu
        de courir après chaque cycle. Mélange dominé par le mean, petite part au courant.
        """
        if sigma <= 0 or len(self.history) < self.cfg.sigma_samples:
            return value  # pas assez d'historique pour juger un "pic"
        mean = sum(self.history) / len(self.history)
        if abs(value - mean) > self.cfg.hyst_peak * sigma:
            return 0.8 * mean + 0.2 * value
        return value

    def _deadband(self, value: float, sigma: float) -> float:
        """Deadband biaisée anti-export (§6bis-4), largeur adaptative à σ.

        Cible de régulation = P1 = +shift (léger import), pas 0. La bande est centrée
        sur la demande qui laisserait exactement +shift d'import : v = value - shift,
        v == 0 <=> cible atteinte. Largeur = min + σ·mult (s'élargit les jours volatils).

        - DANS la bande (|v| <= largeur) : on laisse les onduleurs revenir au REPOS —
          la commande dérive vers 0 (au plus `drift` W/cycle), on tolère l'excursion P1
          dans la bande. Évite de tenir un micro-setpoint précis qui fait osciller.
        - HORS bande : on commande la sous-livraison cible v (= value - shift), qui
          laisse +shift d'import (côté charge : sur-absorbe de shift, même biais import).

        Exception anti-export : un CHANGEMENT DE SIGNE n'est jamais du bruit à ignorer.
        Si le signal a basculé à l'opposé de la commande courante, on NE dérive PAS
        paresseusement (sinon, σ gonflé par le step élargit la bande et on continue de
        décharger dans une maison déjà en surplus -> gros export). On laisse passer v
        vers le direction-guard, qui coupe la commande à 0 immédiatement.
        """
        v = value - self.cfg.deadband_shift
        width = self.cfg.deadband_min + self.cfg.deadband_sigma * sigma
        if abs(v) <= width and self.prev_out * value >= 0:
            out = self.prev_out
            if out > 0:
                return max(0.0, out - self.cfg.drift)
            if out < 0:
                return min(0.0, out + self.cfg.drift)
            return 0.0
        return v

    def _guard(self, value: float, elapsed: float) -> float:
        """Anti-flip charge<->décharge : ne bascule pas de mode sur un transitoire.

        Variante asymétrique de zoic21 (§6bis-2/3) : on AUTORISE la coupure rapide
        vers 0 (recul), mais on REFUSE de franchir 0 vers le mode opposé tant qu'une
        demande opposée soutenue n'est pas confirmée. Sur une grosse chute qui
        franchirait 0, on arme le gel : la sortie est bornée du côté courant (état
        « neutre armé », acMode tenu) pendant au plus guard_max secondes.
        """
        # Décompte d'un gel en cours.
        if self.guard_remaining > 0:
            self.guard_remaining -= elapsed
            if self.guard_remaining > 0:
                # Gel actif : on borne du côté figé (pas de flip), recul vers 0 permis.
                if self.guard_side > 0:
                    return max(0.0, value)
                return min(0.0, value)
            self.guard_side = 0  # gel expiré -> flip autorisé

        # Détection d'un franchissement de 0 brutal (grosse chute opposée).
        crossing = (self.prev_out * value) < 0
        drop = abs(self.prev_out - value)
        if crossing and drop > self.cfg.guard_threshold:
            self.guard_side = 1 if self.prev_out > 0 else -1
            self.guard_remaining = self.cfg.guard_max
            return 0.0  # neutre armé : on reste du côté courant, magnitude nulle
        return value
